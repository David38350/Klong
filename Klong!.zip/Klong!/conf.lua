-- Fichier de configuration
function love.conf(t)
	t.identity = nil
--	t.version  = "11.4"
	t.console  = false 
 
	t.window.title          = "Whack The Mole"
	t.window.icon           = nil
	t.window.width          = 0
	t.window.height         = 0
	t.window.borderless     = true
	t.window.resizable      = false
	--t.window.minwidth       = 640
	--t.window.minheight      = 480
	t.window.fullscreen     = true
	t.window.fullscreentype = "desktop" 
	t.window.vsync          = true
	t.window.fsaa           = 0
	t.window.display        = 1
	t.window.highdpi        = true
	t.window.usedpiscale	= true
   t.window.srgb           = false
 
	t.modules.audio    = true
	t.modules.event    = true
	t.modules.graphics = true
	t.modules.image    = true
	t.modules.joystick = true
	t.modules.keyboard = true
	t.modules.math     = true
	t.modules.mouse    = true
	t.modules.physics  = true
	t.modules.sound    = true
	t.modules.system   = true
	t.modules.timer    = true
	t.modules.window   = true
 
	io.stdout:setvbuf("no")
end

function love.conf(w)
    --Titre de la fenetre
    w.title = "Klong!"
    --Taille de la fenetre
    w.window.width = 0
    w.window.height = 0
end
