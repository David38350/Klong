widht,height = love.graphics.getDimensions()

player = {}
player.size = 1
player.posX = 950
player.posY = 500
player.speed = 10

sun = {}
sun.size = 0.8
sun.posX = 1920
sun.posY = 950
sun.speed = 0.5


moon = {}
moon.size = 0.8
moon.posX = -500
moon.posY = 300
moon.speed = 0.5

stars = {}
stars.size = 0.8
stars.posX = 2500
stars.posY = 600
stars.speed = 1
stars.rotation=45
stars.rotation_speed=0.001

cloud = {}
cloud.size = 0.8
cloud.posX = -600
cloud.posY = 400
cloud.speed = 0.8

global = {}
global.speed = 10

background_day = love.graphics.newImage("assets/images/background_day.png")
background_night = love.graphics.newImage("assets/images/background_night.png")
hole = love.graphics.newImage("assets/images/hole.png")
Klong = love.graphics.newImage("assets/images/klong.png")
sunny = love.graphics.newImage("assets/images/sun.png")
night = love.graphics.newImage("assets/images/moon.png")
constellation = love.graphics.newImage("assets/images/constellation.png")
cloudy = love.graphics.newImage("assets/images/cloud.png")
playerL = love.graphics.newImage("assets/images/playerL.png")
playerR = love.graphics.newImage("assets/images/playerR.png")
playerLNight = love.graphics.newImage("assets/images/playerLNight.png")
playerRNight = love.graphics.newImage("assets/images/playerRNight.png")
player_orientation_day = playerL
player_orientation_night = playerLNight
day = sunny
season = winter

function love.load()
end

function love.update(dt) --Tourne en boucle
input_utilisateur(dt)
    if day == sunny then
        moving_sun(dt)
    else moving_moon(dt);
        moving_stars(dt)
    end
    moving_cloud(dt)
end


function love.draw()
    -- love.graphics.setColor(0,0,0, 1)
    -- love.graphics.setFont(font)
    -- love.graphics.printf("Pos joueur : "..player.posX..", "..player.posY, 10, 10, 1280, left, 1)
    -- love.graphics.printf("Sun Pos : "..sun.posX..", "..sun.posY, 20, 20, 1280, left, 1)
    -- love.graphics.printf("Sun State : "..day..", Déclinaison : "..season, 30, 30, 1280, left, 1)
    -- love.graphics.print("Width : "..width .."\n".."Height : "..height, 0, 0)
    local safeX, safeY, safeW, safeH = love.window.getSafeArea()


    -- Affichage du background en fonction de la variable day (sunny/night)
    if day == sunny then
        love.graphics.draw(background_day, 0, 0, 0, 1, 1)
    else love.graphics.draw(background_night, 0, 0, 0, 1, 1)
    end

-- Affichage d'un trou sur la map    
    love.graphics.draw(hole, 800, 800, 0, 1, 1)

-- Affichage du Joueur    
    if day == sunny then
        love.graphics.draw(player_orientation_day, player.posX, player.posY, 0, player.size, player.size)
    else love.graphics.draw(player_orientation_night, player.posX, player.posY, 0, player.size, player.size)
    end

-- Affichage de la météo
    love.graphics.draw(cloudy, cloud.posX, cloud.posY, 0, cloud.size, cloud.size)
    
-- Affichage des objets célestes (sun/moon/constellation)    
    if day == sunny then
        love.graphics.draw(day, sun.posX, sun.posY, 0, sun.size, sun.size)
    else love.graphics.draw(day, moon.posX, moon.posY, 0, moon.size, moon.size);
        love.graphics.draw(constellation, stars.posX, stars.posY, stars.rotation, stars.size, stars.size)
    end
end    

-- Surveille les entrées clavier (déplacements du joueur)
function input_utilisateur()
    if love.keyboard.isDown("escape") then
        love.events.quit()
    end

    if love.keyboard.isDown("up") then
        player.posY = player.posY - player.speed
    end
    if love.keyboard.isDown("down") then
        player.posY = player.posY + player.speed
    end
    if love.keyboard.isDown("left") then
        player.posX = player.posX - player.speed
        player_orientation_day = playerL
        player_orientation_night = playerLNight
    end
    if love.keyboard.isDown("right") then
        player.posX = player.posX + player.speed
        player_orientation_day = playerR
        player_orientation_night = playerRNight
    end
    if love.keyboard.isDown("escape") then
        love.event.quit()
    end
end


-- Déplacement du soleil
function moving_sun()
    if season == winter and sun.posY < 750 then
        season = summer -- Solstice d'été (changement d'état de déclinaison solaire)
    elseif season == summer and sun.posY > 950 then
        season = winter -- Solstice d'hiver (changement d'état de déclinaison solaire)
    else season = season
    end
    if sun.posX > 800 then
        sun.posY = sun.posY - 0.1 
    else sun.posY = sun.posY + 0.1
    end
    sun.posX = sun.posX - sun.speed * global.speed
    if sun.posX > -300 then
        sun.posX = sun.posX - sun.speed * global.speed
    else day = night
        moon.posX = -300
    end
end

-- Déplacement de la lune
function moving_moon()
    moon.posX = moon.posX + moon.speed * global.speed
    if moon.posX < 1920 then
        moon.posX = moon.posX + moon.speed * global.speed
    else day = sunny 
        sun.posX = 1920
        if sun.season == winter and sun.posY > 450 then 
            sun.posY = sun.posY - 50 -- Déclinaison solaire montante
        elseif sun.season == summer and sun.posY < 950 then
             sun.posY = sun.posY + 50 -- Déclinaison solaire descendante
        end
    end    
end

-- Déplacement de la constellation de la grande ourse
function moving_stars()
    stars.posX = stars.posX - stars.speed * global.speed
    if stars.posX > -1000 then
        stars.posX = stars.posX - stars.speed * global.speed
            else stars.posX = 2000
            end
    if stars.rotation < 45 then 
        stars.rotation = stars.rotation + stars.rotation_speed
            else stars.rotation = 0
        end
    end    

-- Déplacement du nuage
function moving_cloud()
    cloud.posX = cloud.posX + cloud.speed
    if cloud.posX < 2000 then
        cloud.posX = cloud.posX + cloud.speed
    else cloud.posX = -600
    end    
end
 